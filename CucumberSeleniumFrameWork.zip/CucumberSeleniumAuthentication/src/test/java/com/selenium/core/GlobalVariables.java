package com.selenium.core;

public class GlobalVariables {
	public static String browserName;
	public static long timeout;
	public static String url;

}
